package pe.edu.upeu.sysobraconstrucionesylicencias.config;

import pe.edu.upeu.sysobraconstrucionesylicencias.controller.*;
import pe.edu.upeu.sysobraconstrucionesylicencias.repository.*;
import pe.edu.upeu.sysobraconstrucionesylicencias.service.*;
import pe.edu.upeu.sysobraconstrucionesylicencias.service.impl.*;
import java.util.HashMap;
import java.util.Map;

public class AppContext {

    // Singleton: una sola instancia en toda la app
    private static AppContext instance;

    public static synchronized AppContext getInstance() {
        if (instance == null) instance = new AppContext();
        return instance;
    }

    // El "directorio": Clase -> Objeto
    private final Map<Class<?>, Object> contenedor = new HashMap<>();

    // Constructor privado: aqui se arma toda la aplicacion
    private AppContext() {
        registrarRepositorios();
        registrarServicios();
        registrarControladores();
    }

    // CAPA 1 — REPOSITORIOS
    private void registrarRepositorios() {
        registrar(LicenciaObraRepository.class, new LicenciaObraRepository());
    }

    // CAPA 2 — SERVICIOS (reciben su repositorio por constructor)
    private void registrarServicios() {
        registrar(ILicenciaObraService.class, new LicenciaObraServiceImp(getBean(LicenciaObraRepository.class)));
    }

    // CAPA 3 — CONTROLADORES JavaFX (reciben los servicios por constructor)
    private void registrarControladores() {
        registrar(MainGuiController.class, new MainGuiController());
        registrar(LicenciaObraController.class,
                new LicenciaObraController(getBean(ILicenciaObraService.class)));
    }

    /** Guarda un objeto en el directorio, indexado por su tipo o interfaz. */
    private void registrar(Class<?> tipo, Object bean) {
        contenedor.put(tipo, bean);
    }

    /** Busca y devuelve un objeto por su tipo o interfaz. */
    @SuppressWarnings("unchecked")
    public <T> T getBean(Class<T> tipo) {
        Object bean = contenedor.get(tipo);
        if (bean == null) {
            bean = contenedor.values().stream()
                    .filter(b -> tipo.isAssignableFrom(b.getClass()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(
                            "Bean no encontrado: " + tipo.getName() +
                                    "\n-> ¿Lo registraste en AppContext?"));
        }
        return (T) bean;
    }
}
