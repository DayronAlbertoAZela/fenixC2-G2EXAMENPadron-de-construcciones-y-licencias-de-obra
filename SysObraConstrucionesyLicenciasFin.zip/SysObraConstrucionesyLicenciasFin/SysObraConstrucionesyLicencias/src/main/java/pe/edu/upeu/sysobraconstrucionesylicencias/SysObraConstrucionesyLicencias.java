package pe.edu.upeu.sysobraconstrucionesylicencias;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;
import pe.edu.upeu.sysobraconstrucionesylicencias.config.AppContext;

import java.io.IOException;

public class SysObraConstrucionesyLicencias extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Screen screen=Screen.getPrimary();
        Rectangle2D rectangle2D=screen.getVisualBounds();
        AppContext appContext=AppContext.getInstance();
        // Ventana principal con menu. Para abrir directo el CRUD (como en clase)
        // cambiar por: "/view/main_licencia.fxml"
        FXMLLoader fxmlLoader = new FXMLLoader(SysObraConstrucionesyLicencias.class.getResource("/view/maingui.fxml"));
        fxmlLoader.setControllerFactory(appContext::getBean);
        Scene scene = new Scene(fxmlLoader.load(), rectangle2D.getWidth(), rectangle2D.getHeight()-50);
        scene.getStylesheets().add(SysObraConstrucionesyLicencias.class.getResource("/css/style.css").toExternalForm());
        stage.setTitle("Padron de Construcciones y Licencias de Obra");
        stage.setScene(scene);
        stage.show();
    }
}
