package pe.edu.upeu.sysobraconstrucionesylicencias.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.sysobraconstrucionesylicencias.components.ColumnInfo;
import pe.edu.upeu.sysobraconstrucionesylicencias.components.TableViewHelper;
import pe.edu.upeu.sysobraconstrucionesylicencias.components.Toast;
import pe.edu.upeu.sysobraconstrucionesylicencias.components.ToltipCustom;
import pe.edu.upeu.sysobraconstrucionesylicencias.dto.ComboBoxOption;
import pe.edu.upeu.sysobraconstrucionesylicencias.enums.TipoObra;
import pe.edu.upeu.sysobraconstrucionesylicencias.exception.LicenciaDuplicadaException;
import pe.edu.upeu.sysobraconstrucionesylicencias.model.LicenciaObra;
import pe.edu.upeu.sysobraconstrucionesylicencias.service.ILicenciaObraService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

@RequiredArgsConstructor
public class LicenciaObraController {
    private final ILicenciaObraService los;

    @FXML
    TextField txtNumeroLicencia, txtDireccion, txtPropietario, txtFiltroDato;
    @FXML
    ComboBox<ComboBoxOption> cbxTipoObra;
    @FXML
    DatePicker dpFechaInicio, dpFechaFin;

    @FXML private TableView<LicenciaObra> tableView;

    @FXML
    Label lbnMsg;
    @FXML private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<LicenciaObra> listarLicencias;
    LicenciaObra formulario;
    Long idLicenciaCE = 0L;

    private final ToltipCustom ttc=new ToltipCustom();

    @FXML
    public void initialize(){
        cbxTipoObra.getItems().addAll(los.listarTipoObra());

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<LicenciaObra> tableViewHelper = new TableViewHelper<>();

        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idLicencia", 50.0));
        columns.put("N. Licencia", new ColumnInfo("numeroLicencia", 110.0));
        columns.put("Tipo de Obra", new ColumnInfo("tipoObra", 140.0));
        columns.put("Direccion", new ColumnInfo("direccion", 200.0));
        columns.put("Propietario", new ColumnInfo("propietario", 170.0));
        columns.put("F. Inicio", new ColumnInfo("fechaInicio", 100.0));
        columns.put("F. Fin Prevista", new ColumnInfo("fechaFin", 110.0));

        Consumer<LicenciaObra> updateAction = licencia -> { editForm(licencia); };
        Consumer<LicenciaObra> deleteAction = licencia -> { eliminar(licencia); };

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setTableMenuButtonVisible(true);

        txtFiltroDato.textProperty().addListener((obs, o, n) -> filtrarLicencias(n));
        lbnMsg.setText("");
        listar();
    }

    public void listar() {
        try {
            listarLicencias = FXCollections.observableArrayList(los.findAll());
            filtrarLicencias(txtFiltroDato.getText());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void filtrarLicencias(String filtro) {
        if (filtro == null || filtro.isBlank()) {
            tableView.getItems().setAll(listarLicencias);
        } else {
            String f = filtro.toLowerCase();
            List<LicenciaObra> filtrados = listarLicencias.stream()
                    .filter(l -> l.getNumeroLicencia().toLowerCase().contains(f)
                            || l.getPropietario().toLowerCase().contains(f)
                            || l.getDireccion().toLowerCase().contains(f)
                            || l.getTipoObra().getDescripcion().toLowerCase().contains(f))
                    .toList();
            tableView.getItems().setAll(filtrados);
        }
    }

    @FXML
    public void validarFormulario() {
        formulario = new LicenciaObra();
        formulario.setNumeroLicencia(txtNumeroLicencia.getText().trim());
        formulario.setDireccion(txtDireccion.getText().trim());
        formulario.setPropietario(txtPropietario.getText().trim());
        formulario.setFechaInicio(leerFecha(dpFechaInicio));
        formulario.setFechaFin(leerFecha(dpFechaFin));

        String idxTO = cbxTipoObra.getSelectionModel().getSelectedItem() == null ? ""
                : cbxTipoObra.getSelectionModel().getSelectedItem().getKey();
        formulario.setTipoObra(idxTO.equals("") ? null : TipoObra.valueOf(idxTO));

        Set<ConstraintViolation<LicenciaObra>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<LicenciaObra>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();
        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private LocalDate leerFecha(DatePicker dp) {
        try {
            String texto = dp.getEditor().getText();
            if (texto != null && !texto.isBlank()) {
                dp.setValue(dp.getConverter().fromString(texto.trim()));
            }
        } catch (Exception e) {
            dp.setValue(null);
        }
        return dp.getValue();
    }

    @FXML
    public void clearForm() {
        txtNumeroLicencia.clear();
        txtNumeroLicencia.setEditable(true);
        cbxTipoObra.getSelectionModel().clearSelection();
        txtDireccion.clear();
        txtPropietario.clear();
        dpFechaInicio.setValue(null);
        dpFechaFin.setValue(null);
        idLicenciaCE = 0L;
        limpiarError();
        lbnMsg.setText("");
    }

    public void editForm(LicenciaObra licencia) {
        txtNumeroLicencia.setText(licencia.getNumeroLicencia());
        txtNumeroLicencia.setEditable(false);
        txtDireccion.setText(licencia.getDireccion());
        txtPropietario.setText(licencia.getPropietario());
        dpFechaInicio.setValue(licencia.getFechaInicio());
        dpFechaFin.setValue(licencia.getFechaFin());

        cbxTipoObra.getSelectionModel().select(
                cbxTipoObra.getItems().stream()
                        .filter(t -> t.getKey().equals(licencia.getTipoObra().name()))
                        .findFirst().orElse(null));

        idLicenciaCE = licencia.getIdLicencia();
        limpiarError();
        lbnMsg.setText("Editando licencia " + licencia.getNumeroLicencia());
        lbnMsg.setStyle("-fx-text-fill: blue; -fx-font-size: 16px;");
    }

    private void eliminar(LicenciaObra licencia) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar la licencia " + licencia.getNumeroLicencia() + "?",
                ButtonType.YES, ButtonType.NO);
        alert.setHeaderText(null);
        Optional<ButtonType> respuesta = alert.showAndWait();
        if (respuesta.isPresent() && respuesta.get() == ButtonType.YES) {
            stage = (Stage) miContenedor.getScene().getWindow();
            los.delete(licencia.getIdLicencia());
            double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            clearForm();
            listar();
        }
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<LicenciaObra>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("numeroLicencia", txtNumeroLicencia);
        campos.put("tipoObra", cbxTipoObra);
        campos.put("direccion", txtDireccion);
        campos.put("propietario", txtPropietario);
        campos.put("fechaInicio", dpFechaInicio);
        campos.put("fechaFin", dpFechaFin);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {
                        erroresOrdenados.put(campo, v.getMessage());
                        Control c = campos.get(campo);
                        if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.entrySet().iterator().next().getValue());
            lbnMsg.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        limpiarError();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            if (idLicenciaCE > 0L) {
                formulario.setIdLicencia(idLicenciaCE);
                los.update(idLicenciaCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente!!", 2000, w, h);
            } else {
                los.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente!!", 2000, w, h);
            }
            clearForm();
            listar();
            lbnMsg.setText("Formulario válido");
            lbnMsg.setStyle("-fx-text-fill: green; -fx-font-size: 16px;");
        } catch (LicenciaDuplicadaException e) {
            ttc.marcarError(txtNumeroLicencia, e.getMessage());
            lbnMsg.setText(e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
        } catch (IllegalArgumentException e) {
            ttc.marcarError(dpFechaFin, e.getMessage());
            lbnMsg.setText(e.getMessage());
            lbnMsg.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
        }
    }

    public void limpiarError() {
        List.of(txtNumeroLicencia, cbxTipoObra, txtDireccion, txtPropietario, dpFechaInicio, dpFechaFin)
                .forEach(c -> ttc.limpiarCampo(c));
    }

}
